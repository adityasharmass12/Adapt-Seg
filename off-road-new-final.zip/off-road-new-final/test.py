# LOAD MODEL


model.load_state_dict(torch.load("/kaggle/working/best_model.pth"))
model.eval()
print("Model loaded")



def compute_real_iou(pred, target, num_classes=10):
    pred = torch.argmax(pred, dim=1)

    ious = []
    for cls in range(num_classes):
        pred_inds = (pred == cls)
        target_inds = (target == cls)

        intersection = (pred_inds & target_inds).sum().float()
        union = (pred_inds | target_inds).sum().float()

        if union == 0:
            continue

        ious.append((intersection / union).item())

    return np.mean(ious) if len(ious) > 0 else 0





# TESTING LOOP

test_ious = []

with torch.no_grad():
    for img, mask in tqdm(val_loader):   # val_loader = test_loader if separate
        img, mask = img.to(DEVICE), mask.to(DEVICE)

        # ORIGINAL
        feat = backbone.forward_features(img)["x_norm_patchtokens"]
        out1 = model(feat, IMG_H//14, IMG_W//14)
        out1 = F.interpolate(out1, size=(IMG_H, IMG_W))

        # FLIP TTA 
        img_flip = torch.flip(img, dims=[3])
        feat_flip = backbone.forward_features(img_flip)["x_norm_patchtokens"]

        out2 = model(feat_flip, IMG_H//14, IMG_W//14)
        out2 = F.interpolate(out2, size=(IMG_H, IMG_W))
        out2 = torch.flip(out2, dims=[3])

        # FINAL
        out = (out1 + out2) / 2

        iou = compute_real_iou(out, mask)
        test_ious.append(iou)


# FINAL RESULT
mean_iou = np.mean(test_ious)

print("\n TEST RESULTS")
print("="*40)
print(f"Mean IoU: {mean_iou:.4f}")
print("="*40)