EPOCHS = 15
best_iou = 0

for epoch in range(EPOCHS):
    model.train()
    total_loss = 0

    for img, mask in tqdm(train_loader):
        img, mask = img.to(DEVICE), mask.to(DEVICE)

        with torch.no_grad():
            feat = backbone.forward_features(img)["x_norm_patchtokens"]

        out = model(feat, IMG_H//14, IMG_W//14)
        out = F.interpolate(out, size=(IMG_H, IMG_W))

        loss = loss_fn(out, mask)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    # ===== VALIDATION WITH TTA =====
    model.eval()
    ious = []

    with torch.no_grad():
        for img, mask in val_loader:
            img, mask = img.to(DEVICE), mask.to(DEVICE)

            # ORIGINAL
            feat = backbone.forward_features(img)["x_norm_patchtokens"]
            out1 = model(feat, IMG_H//14, IMG_W//14)
            out1 = F.interpolate(out1, size=(IMG_H, IMG_W))

            # FLIP
            img_flip = torch.flip(img, dims=[3])
            feat_flip = backbone.forward_features(img_flip)["x_norm_patchtokens"]

            out2 = model(feat_flip, IMG_H//14, IMG_W//14)
            out2 = F.interpolate(out2, size=(IMG_H, IMG_W))
            out2 = torch.flip(out2, dims=[3])

            # FINAL
            out = (out1 + out2) / 2

            ious.append(compute_iou(out, mask))

    val_iou = np.mean(ious)

    print(f"Epoch {epoch+1}/15 | Loss {total_loss:.3f} | IoU {val_iou:.4f}")

    # SAVE BEST MODEL
    if val_iou > best_iou:
        best_iou = val_iou
        torch.save(model.state_dict(), "/kaggle/working/best_model.pth")
        print("Best model saved!")

print("FINAL BEST IOU:", best_iou)