#1) Install


!pip install timm opencv-python



#2) Import Libraries


import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as transforms
from torch.utils.data import Dataset, DataLoader
import numpy as np
from PIL import Image
import os
from tqdm import tqdm

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

DATA_DIR = "/kaggle/input/YOUR-DATASET-NAME"  # CHANGE
BATCH_SIZE = 8
EPOCHS = 60
LR = 3e-4
NUM_CLASSES = 10
IMG_H, IMG_W = 448, 896

print("Using:", DEVICE)




#3) Mask Mapping


value_map = {
    0: 0, 100: 1, 200: 2, 300: 3,
    500: 4, 550: 5, 700: 6,
    800: 7, 7100: 8, 10000: 9
}

def convert_mask(mask):
    arr = np.array(mask)
    new = np.zeros_like(arr, dtype=np.uint8)
    for k,v in value_map.items():
        new[arr == k] = v
    return Image.fromarray(new)




#4) Dataset Class


    class SegDataset(Dataset):
    def __init__(self, root, train=True):
        self.img_dir = os.path.join(root, "Color_Images")
        self.mask_dir = os.path.join(root, "Segmentation")
        self.ids = os.listdir(self.img_dir)

        if train:
            self.img_tf = transforms.Compose([
                transforms.Resize((IMG_H, IMG_W)),
                transforms.RandomHorizontalFlip(),
                transforms.ColorJitter(0.3,0.3,0.3,0.1),
                transforms.ToTensor(),
                transforms.Normalize([0.485,0.456,0.406],
                                     [0.229,0.224,0.225])
            ])
        else:
            self.img_tf = transforms.Compose([
                transforms.Resize((IMG_H, IMG_W)),
                transforms.ToTensor(),
                transforms.Normalize([0.485,0.456,0.406],
                                     [0.229,0.224,0.225])
            ])

        self.mask_tf = transforms.Compose([
            transforms.Resize((IMG_H, IMG_W)),
            transforms.ToTensor()
        ])

    def __len__(self):
        return len(self.ids)

    def __getitem__(self, i):
        name = self.ids[i]

        img = Image.open(os.path.join(self.img_dir, name)).convert("RGB")
        mask = convert_mask(Image.open(os.path.join(self.mask_dir, name)))

        img = self.img_tf(img)
        mask = (self.mask_tf(mask)*255).long().squeeze(0)

        return img, mask




#5) Load Dataset



        import os

print(os.listdir("/kaggle/input"))




#6) Setting Directory



DATA_DIR = "/kaggle/input/datasets/roheeeeet/rohit-xeno/Offroad_Segmentation_Training_Dataset/Offroad_Segmentation_Training_Dataset"






#7) DataSet Path



train_ds = SegDataset(DATA_DIR + "/train", train=True)
val_ds   = SegDataset(DATA_DIR + "/val", train=False)

train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True, num_workers=2)
val_loader   = DataLoader(val_ds, batch_size=BATCH_SIZE, shuffle=False, num_workers=2)

print(len(train_ds), len(val_ds))



#8) Loading DINOv2 BACKBONE



backbone = torch.hub.load("facebookresearch/dinov2", "dinov2_vits14")
backbone.to(DEVICE)
backbone.eval()







#9) SegFormer Head



class SegFormerHead(nn.Module):
    def __init__(self, in_channels, num_classes):
        super().__init__()

        self.conv1 = nn.Conv2d(in_channels, 256, 1)
        self.bn = nn.BatchNorm2d(256)

        self.conv2 = nn.Conv2d(256, 128, 3, padding=1)
        self.conv3 = nn.Conv2d(128, num_classes, 1)

    def forward(self, x, H, W):
        B, N, C = x.shape
        x = x.reshape(B, H, W, C).permute(0,3,1,2)

        x = F.relu(self.bn(self.conv1(x)))
        x = F.relu(self.conv2(x))
        return self.conv3(x)



#10) Model Initialization




        dummy = torch.randn(1,3,IMG_H,IMG_W).to(DEVICE)
feat = backbone.forward_features(dummy)["x_norm_patchtokens"]
EMB = feat.shape[-1]

model = SegFormerHead(EMB, NUM_CLASSES).to(DEVICE)



#11) Loss Function



class DiceLoss(nn.Module):
    def forward(self, pred, target):
        pred = F.softmax(pred, dim=1)
        target = F.one_hot(target, NUM_CLASSES).permute(0,3,1,2).float()

        inter = (pred * target).sum((2,3))
        union = pred.sum((2,3)) + target.sum((2,3))
        dice = (2*inter + 1e-6)/(union + 1e-6)
        return 1 - dice.mean()

dice_loss = DiceLoss()

def loss_fn(pred, target):
    ce = F.cross_entropy(pred, target)
    return 0.5*ce + 0.5*dice_loss(pred, target)




#12) Optimizer



    optimizer = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=1e-4)




#13) IOU Function




    def compute_iou(pred, target):
    pred = torch.argmax(pred,1)
    return (pred==target).float().mean().item()







